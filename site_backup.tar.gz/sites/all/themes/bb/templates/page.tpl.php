<div id="wrapper">
	
	<div id="header">
		<div id="header-inner" class="clearfix">
			<div class="menu-toggle">Menu</div>
			<div id="nav"><?php print render($page['nav_main']); ?></div> 
		</div>
		<div class="bot"></div>
		<div id="ud-sm">
			<div id="u-sm"><a href="/ud"><img src="/ud/sites/all/themes/bb/images/u_sm.png" alt="u"></a></div>
			<div id="d-sm"><a href="/ud"><img src="/ud/sites/all/themes/bb/images/d_sm.png" alt="d"></a></div>

			<div id="logo">
				<a href="/ud">Upstairs <span>Downstairs</span></a>
				<div class="slogan">life stripped down</div>
			</div>
		</div>

	</div>
	
	<?php if($is_front): ?>
	<div id="u-big"><img src="/ud/sites/all/themes/bb/images/u_big.png" alt="u"></div>
	<div id="d-big"><img src="/ud/sites/all/themes/bb/images/d_big.png" alt="d"></div>

	<div id="logo">
		<a href="/ud">Upstairs <span>Downstairs</span></a>
		<div class="slogan">life stripped down</div>
	</div>
	<?php endif; ?>
	

	<div id="main-content">
		
		<div id="main">
			<div id="main-inner">
				<div id="content">
					<?php if($title && !$is_front): ?>
						<h1 class="main-title"><?php echo $title; ?></h1>
					<?php endif; ?>
					
					<?php echo render($page['content']); ?>
				</div>
			</div>
		</div>
		
		<?php if(!$page['sidebar_first']): ?> 
			<div id="side">
				<div id="side-inner">
					<div id="content"><?php echo render($page['sidebar_first']); ?></div>
				</div>
			</div>
		<?php endif; ?>
	</div>

</div>

<div id="footer">
	<div id="footer-iner">
		<div id="copy">&copy; <?php echo date('Y'); ?> Don't steal. It's not nice.</div>
	</div>
</div>
