<div class="comment">
	<div class="comment-header clearfix">
		<h2><?php echo $author; ?></h2>
		<h3><?php echo $created; ?></h3>
		
	</div>
	
	<div class="body clearfix">
		<?php echo $body; ?>
	</div>
	<div class="footer clearfix">
		<div class="website"><?php echo $website; ?></div>
		<?php echo $links; ?>
	</div>
</div>