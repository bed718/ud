Drupal.behaviors.init = {
	attach: function (context, settings) {
		

		// SERVICE LINKS TOGGLE
		jQuery('.share-btn').click(function(){

			jQuery(this).next().slideToggle();
			return false;

		});

		// COMMENT FORM
		jQuery('.add-comment-btn').click(function(){
			jQuery('.comment-form-holder').slideToggle();
		});

		var udsmopen = false;

		jQuery(window).scroll(function (e) {
		    var windowScroll = jQuery(window).scrollTop(),
		    speed = 1.8,
		    pos = 60 - windowScroll * speed;
		 	jQuery('#u-big').css('top',  pos );

		 	if(windowScroll > 200 & !udsmopen){
		 		showUDS();
		 	}else if(windowScroll < 200 & udsmopen){
		 		hideUDS();
		 	}

		 	console.log(windowScroll);


		});

		function showUDS(){
			jQuery('.front #ud-sm').animate({top: 0}, 500);
			jQuery('.front #header .bot').slideDown(500);
			udsmopen = true;
		}

		function hideUDS(){
			jQuery('.front #ud-sm').animate({top: -180}, 500);
			jQuery('.front #header .bot').slideUp(500);
			udsmopen = false;
		}

		jQuery(window).scroll(function (e) {
		    var windowScroll = jQuery(window).scrollTop(),
		        speed = 1.8,
		        pos = 80 - windowScroll * speed;
		 	   jQuery('#d-big').css('top',  pos );

		});
			

		// MOBILE STUFF
		jQuery('.menu-toggle').click(function(){
			jQuery('#nav').stop(false, true).slideToggle();
		});

		jQuery(window).resize(function(){

			windowResized();
		});


		function windowResized(){
			
			var win_w = jQuery(window).width();
			var win_h = jQuery(window).height();

			if(win_w < 700){
				jQuery('body').addClass('mobile');
			}else{
				jQuery('body').removeClass('mobile');
			}

			//console.log(win_w);
		}

		windowResized();
	}
}

/*Drupal.behaviors.pinit = {
	attach: function (context, settings) {
			
			jQuery('.image-post_full').after('<div class="hover-pinterest"></div>');
			jQuery('.hover-pinterest').append('<a class="pin-it-link" target="_blank"></a>');
			jQuery('.image-post_full').parent().hover(
				function() {
					var pinit = jQuery(this).next();
					var imgurl = jQuery(this).attr('src');
					var encodedurl = encodeURIComponent(imgurl);
					var pathname = jQuery(location).attr('href');
					url = encodeURIComponent(pathname);
					var desc = encodeURIComponent('enter description here');
					var pinhref = 'http://pinterest.com/pin/create/button/?url=';
					pinhref += url;
					pinhref += '&media=';
					pinhref += encodedurl;
					pinhref += '&description=';
					pinhref += desc;
					jQuery('a', pinit).attr('href', pinhref);
					var pinwidth = jQuery(this).parent().width();
					var pinheight = jQuery(this).parent().height();
					pinit.css('display','block');
					pinit.css('width',pinwidth);
					pinit.css('height',pinheight);
				},function() {
					var pinit = jQuery(this).next();
					//pinit.css('display','none');
				});
	
	}
}*/

