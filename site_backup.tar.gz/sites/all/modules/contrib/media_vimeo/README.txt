
Media: Vimeo

Creates a Vimeo PHP Stream Wrapper for Resource and implements the various
formatter and file listing hooks in the Media module.
